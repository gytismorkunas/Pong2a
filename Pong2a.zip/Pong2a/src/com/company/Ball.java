package com.company;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Ball extends GameObject {

    public Ball(int x, int y) {
        super(x, y);
        width = 30;
        height = 30;
        Random r = new Random();
        xvel = r.nextBoolean() ? 1 : -1;
        yvel = r.nextBoolean() ? 1 : -1;
    }

    public void update(Paddle a, Paddle b, int screenWidth, int screenHeight) {
        x += xvel;
        y += yvel;

        if (xvel < 0){
            checkCol(a, false); //only
        }else {
            checkCol(b, true);
        }

        if (y < 0) {
            yvel = -yvel;
        }else if (y+height+40 > screenHeight) {
            yvel = -yvel;
        }

        if (x + width < 0) {
            reset(screenWidth, screenHeight);
            b.score++;
        }else if (x > screenWidth) {
            reset(screenWidth, screenHeight);
            a.score++;
        }
    }

    private void reset(int screenWidth, int screenHeight) {
        x = screenWidth/2-15;
        y = screenHeight/2-15;
        Random r = new Random();
        if (r.nextBoolean()){
            xvel = 1;
        }else{
            xvel = -1;
        }
        //
        yvel = r.nextBoolean() ? 1 : -1;
    }

    private void checkCol(Paddle b, boolean right) {
        int posAddition = b.width;
        if (right){
            posAddition = -width;
        }
        if (b.x + posAddition == x && b.y <= y + height && b.y + b.height >= y) {
            xvel = -xvel;
        }
    }

    @Override
    public void paint(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillOval(x, y, width, height);
    }

}

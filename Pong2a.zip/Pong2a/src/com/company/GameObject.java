package com.company;

import java.awt.Graphics;

public abstract class GameObject {

    public int x, y, xvel, yvel;

    int width, height;


    public GameObject(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract void paint(Graphics g) ; //inheritance
}

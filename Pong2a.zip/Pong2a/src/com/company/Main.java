package com.company;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main extends JPanel implements Runnable{

    private final boolean running;

    private final JFrame frame;

    private final Ball ball;
    private final Bat a;
    private final Bat b;

    public boolean[] keys;

    public static void main(String[] args) {
        new Main();
    }

    public Main() {
        keys = new boolean[4];

        this.setLayout(null);
        this.setBackground(Color.black);
        frame = new JFrame("Pong Game");
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setContentPane(this);

        frame.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    keys[0] = true;
                }else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    keys[1] = true;
                }else if (e.getKeyCode() == KeyEvent.VK_W) {
                    keys[2] = true;
                }else if (e.getKeyCode() == KeyEvent.VK_S) {
                    keys[3] = true;
                }
            }
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_UP) {
                    keys[0] = false;
                }else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    keys[1] = false;
                }else if (e.getKeyCode() == KeyEvent.VK_W) {
                    keys[2] = false;
                }else if (e.getKeyCode() == KeyEvent.VK_S) {
                    keys[3] = false;
                }
            }
        });

        ball = new Ball(frame.getWidth()/2-15, frame.getHeight()/2-15);
        a = new Bat(50, frame.getHeight()/2-40);
        b = new Bat(frame.getWidth()-65, frame.getHeight()/2-40);

        running = true;
        Thread mainThread = new Thread(this);
        mainThread.start();

        frame.setVisible(true);
    }

    private void update() {
        ball.update(a, b, frame.getWidth(), frame.getHeight());
        if ((keys[0] && !keys[1]) || (!keys[0] && keys[1])) {
            if (keys[0]) {
                b.yvel = -2;
            }else {
                b.yvel = 2;
            }
        }else {
            b.yvel = 0;
        }
        if (keys[3] ^ keys[2]) {
            if (keys[2]) {
                a.yvel = -2;
            }else {
                a.yvel = 2;
            }
        }else {
            a.yvel = 0;
        }
        a.update(frame.getHeight());
        b.update(frame.getHeight());
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
       g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setFont(new Font ("TimesRoman", Font.BOLD | Font.PLAIN, 35));
        g.setColor(Color.BLUE);
        a.paint(g);
        g.setColor(Color.RED);
        b.paint(g);
        ball.paint(g);
        g.drawLine(frame.getWidth()/2, 0, frame.getWidth()/2, frame.getHeight());
        g.drawString(a.score + "", frame.getWidth()/2 - 30, 40);
        g.drawString(b.score + "", frame.getWidth()/2 + 15, 40);
    }

    @Override
    public void run() {
        while (running) {
            try {
                Thread.sleep(5);
                update();
                repaint();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

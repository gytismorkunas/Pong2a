package com.company;

import java.awt.Graphics;

public class Bat extends GameObject {

    int score;

    public Bat(int x, int y) {
        super(x, y);
        width = 15;
        height = 80;
    }

    public void update(int screenHeight) {
        y += yvel;
        y = Math.max(0,Math.min(y, screenHeight-height-43));
    }

    @Override
    public void paint(Graphics g) {
        g.fillRect(x, y, width, height);
    }

}
